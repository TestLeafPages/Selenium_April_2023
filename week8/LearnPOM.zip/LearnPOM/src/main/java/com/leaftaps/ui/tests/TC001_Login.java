package com.leaftaps.ui.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.base.ProjectSpecificMethods;
import com.leaftaps.ui.pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethods {
	@BeforeTest
	public void setData() {
		excelFileName = "tc001";
	}
	@Test(dataProvider = "getData")
	public void login(String username, String password) {
		LoginPage page = new LoginPage(driver);
		page.enterUsername(username)
		.enterPassword(password)
		.clickLogin_Positive()
		.verifyWelcomeMessage();
		
		
		
		
		
		
		
		
		
		
		
		
//		page.enterUsername();
//		page.enterPassword();
//		page.clickLogin_Positive();
//		WelcomePage wpage = new WelcomePage();
//		wpage.verifyWelcomeMessage();
	}
}
