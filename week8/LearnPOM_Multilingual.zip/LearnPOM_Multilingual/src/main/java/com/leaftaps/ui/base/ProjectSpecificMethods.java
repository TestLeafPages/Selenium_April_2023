package com.leaftaps.ui.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.leaftaps.ui.utility.ReadExcelData;

public class ProjectSpecificMethods {
	public String excelFileName;
	public RemoteWebDriver driver;
	public static Properties langProp;
	
	@BeforeMethod
	public void startApp() throws Exception {
		// Read the AppConfig.property to know the browser, url & language to run
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream("./config/AppConfig.properties");
		prop.load(file);
		if (prop.getProperty("browser").equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (prop.getProperty("browser").equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		
		String lang = prop.getProperty("language");
		
		langProp = new Properties();
		FileInputStream file1 = new FileInputStream("./config/"+lang+".properties");
		langProp.load(file1);
	}

	@AfterMethod
	public void closeApp() {
		driver.quit();
	}
	
	@DataProvider
	public Object[][] getData() {
		return ReadExcelData.readData(excelFileName);
	}
}
