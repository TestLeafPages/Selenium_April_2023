package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	public LoginPage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
	}

	public LoginPage enterUsername(String username) {
		driver.findElement(By.id(langProp.getProperty("username.id"))).sendKeys(username);
		return this;
	}

	public LoginPage enterPassword(String password) {
		driver.findElement(By.id(langProp.getProperty("password.id"))).sendKeys(password);
//		return new LoginPage();
		return this;
	}

	public WelcomePage clickLogin_Positive() {
		driver.findElement(By.className(langProp.getProperty("login.class"))).click();
		return new WelcomePage(driver);
	}

	public LoginPage clickLogin_Negative() {
		driver.findElement(By.className(langProp.getProperty("login.class"))).click();
		return this;
	}
}
