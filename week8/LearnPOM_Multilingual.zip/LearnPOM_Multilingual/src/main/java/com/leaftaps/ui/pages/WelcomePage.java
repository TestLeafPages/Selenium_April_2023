package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods {
	public WelcomePage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
	}
	public LoginPage clickLogout() {
		driver.findElement(By.className(langProp.getProperty("login.class"))).click();
		return new LoginPage(driver);
	}
	public HomePage clickcrmsfa() {
		driver.findElement(By.linkText(langProp.getProperty("crmsfa.link"))).click();
		return new HomePage(driver);
	}
	public WelcomePage verifyWelcomeMessage() {
		if(driver.findElement(By.tagName("h2")).getText().contains("Welcome")) {
			System.out.println("Welcome message verified");
		}
		else{
			System.out.println("Welcome message not verified");
		}
		return this;
	}
}
