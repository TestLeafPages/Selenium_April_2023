package com.leaftaps.ui.base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.leaftaps.ui.utility.ReadExcelData;

public class ProjectSpecificMethods {
	public String excelFileName;
	public RemoteWebDriver driver;
	@Parameters({"browser","url"})
	@BeforeMethod
	public void startApp(String browser, String url) {
		if (browser.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
	}

	@AfterMethod
	public void closeApp() {
		driver.quit();
	}
	
	@DataProvider
	public Object[][] getData() {
		return ReadExcelData.readData(excelFileName);
	}
}
