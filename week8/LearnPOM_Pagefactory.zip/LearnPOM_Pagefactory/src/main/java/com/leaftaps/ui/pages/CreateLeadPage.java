package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods {
	public CreateLeadPage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id = "createLeadForm_companyName") WebElement elementCName;
	@FindBy(id = "createLeadForm_firstName") WebElement elementFName;
	@FindBy(id = "createLeadForm_lastName") WebElement elementLName;
	@FindBy(className = "smallSubmit") WebElement elementCreateLeadButton;
	public CreateLeadPage enterCompanyName(String cname) {
		elementCName.sendKeys(cname);
		return this;
	}

	public CreateLeadPage enterFirstName(String fname) {
		elementFName.sendKeys(fname);
		return this;

	}

	public CreateLeadPage enterLastName(String lname) {
		elementLName.sendKeys(lname);
		return this;

	}

	public ViewLeadPage clickCreateLeadButton() {
		elementCreateLeadButton.click();
		return new ViewLeadPage(driver);
	}
}
