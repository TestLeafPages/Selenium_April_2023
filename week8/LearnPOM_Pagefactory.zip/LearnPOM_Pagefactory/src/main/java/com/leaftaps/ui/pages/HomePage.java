package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public HomePage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText = "Leads") WebElement elementLeadsLink;
	
	public MyLeadsPage clickLeads() {
		elementLeadsLink.click();
		return new MyLeadsPage(driver);
	}
}
