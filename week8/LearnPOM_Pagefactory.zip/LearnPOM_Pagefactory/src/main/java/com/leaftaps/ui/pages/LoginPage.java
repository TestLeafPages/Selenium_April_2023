package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	public LoginPage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
		PageFactory.initElements(driver, this);
	}
	@CacheLookup
	@FindBy(id = "username") WebElement elementUsername;
	@FindBy(id = "password") WebElement elementPassword;
	@FindBy(className = "decorativeSubmit") WebElement elementLoginButton;
	
	public LoginPage enterUsername(String username) {
		elementUsername.sendKeys(username);
		return this;
	}

	public LoginPage enterPassword(String password) {
		elementPassword.sendKeys(password);
		return this;
	}

	public WelcomePage clickLogin_Positive() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
	}

	public LoginPage clickLogin_Negative() {
		elementLoginButton.click();
		return this;
	}
}
