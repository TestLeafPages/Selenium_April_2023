package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods {
	public MyLeadsPage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText = "Create Lead") WebElement elementCreateLead;
	public CreateLeadPage clickCreateLead() {
		elementCreateLead.click();
		return new CreateLeadPage(driver);
	}
}
