package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods {
	public WelcomePage(RemoteWebDriver getDriver) {
		this.driver = getDriver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(className = "decorativeSubmit") WebElement elementLogoutButton;
	@FindBy(linkText = "CRM/SFA") WebElement elementcrmsfalink;
	public LoginPage clickLogout() {
		elementLogoutButton.click();
		return new LoginPage(driver);
	}
	public HomePage clickcrmsfa() {
		elementcrmsfalink.click();
		return new HomePage(driver);
	}
	public WelcomePage verifyWelcomeMessage() {
		if(driver.findElement(By.tagName("h2")).getText().contains("Welcome")) {
			System.out.println("Welcome message verified");
		}
		else{
			System.out.println("Welcome message not verified");
		}
		return this;
	}
}
