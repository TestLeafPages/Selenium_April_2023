package com.leaftaps.ui.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.base.ProjectSpecificMethods;
import com.leaftaps.ui.pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethods {
	@BeforeTest
	public void setData() {
		excelFileName = "tc002";
	}
	@Test(dataProvider = "getData")
	public void login(String username, String password,String cname, String fname, String lname) {
		LoginPage page = new LoginPage(driver);
		page.enterUsername(username)
		.enterPassword(password)
		.clickLogin_Positive()
		.clickcrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterCompanyName(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.clickCreateLeadButton();
		
		
		
		
		
		
		
		
		
		
		
		
//		page.enterUsername();
//		page.enterPassword();
//		page.clickLogin_Positive();
//		WelcomePage wpage = new WelcomePage();
//		wpage.verifyWelcomeMessage();
	}
}
